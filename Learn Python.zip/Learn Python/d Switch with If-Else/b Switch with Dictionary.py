# We create a dictionary 'outfit_choices' where each weather condition is linked to an outfit
outfit_choices = {
    "rainy": "raincoat",
    "sunny": "sunglasses",
    "snowy": "warm coat"
}

# We have a variable 'weather' that stores today's weather
weather = "sunny"

# We use the weather to find the corresponding outfit from the dictionary, defaulting to 't-shirt' if not found
outfit = outfit_choices.get(weather, "t-shirt")

# We print out the chosen outfit
print(outfit)  # This will show 'sunglasses' because the weather is sunny
