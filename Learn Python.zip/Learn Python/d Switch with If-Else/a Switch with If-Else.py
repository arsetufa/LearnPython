# We have a variable 'weather' that stores today's weather as a word
weather = "sunny"

# We start deciding what to wear based on the weather
if weather == "rainy":
    # If it's rainy, we choose to wear a raincoat
    outfit = "raincoat"
elif weather == "sunny":
    # If it's sunny, we choose to wear sunglasses
    outfit = "sunglasses"
elif weather == "snowy":
    # If it's snowy, we choose to wear a warm coat
    outfit = "warm coat"
else:
    # If the weather is something else, we just choose a t-shirt
    outfit = "t-shirt"

# We print out the chosen outfit
print(outfit)  # This will show 'sunglasses' because the weather is sunny
