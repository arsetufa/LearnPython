# Defining a class named 'Toy'
class Toy:
    # This is a special method that sets up our toy when we make it
    def __init__(self, name, color):
        self.name = name  # Every toy will have a name
        self.color = color  # Every toy will have a color

    # This method allows the toy to introduce itself
    def introduce_self(self):
        print("Hi, I am a " + self.color + " toy named " + self.name + "!")




# Creating two toy objects from the 'Toy' class
toy1 = Toy("Teddy Bear", "brown")  # This is like making a brown teddy bear toy
toy2 = Toy("Race Car", "red")  # This is like making a red race car toy

# Each toy (object) has its own name and color, as specified when we created them.




# Making each toy introduce itself using the 'introduce_self' method
toy1.introduce_self()  # This will print: "Hi, I am a brown toy named Teddy Bear!"
toy2.introduce_self()  # This will print: "Hi, I am a red toy named Race Car!"
