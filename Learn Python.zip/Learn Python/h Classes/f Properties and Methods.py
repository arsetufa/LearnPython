class Toy:
    def __init__(self, name, color):
        self.name = name  # Property: The toy's name
        self.color = color  # Property: The toy's color

    # This is a method; it's something the toy can do.
    def introduce_self(self):
        print("Hi, I am " + self.name + " and I am " + self.color + "!")

# Creating a new toy
my_toy = Toy("Robot", "silver")

# We can ask the toy to introduce itself, which is a method.
my_toy.introduce_self()  # The toy says its name and color.
