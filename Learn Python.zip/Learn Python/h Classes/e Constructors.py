class Toy:
    # This is the constructor method; it sets up our new toy when we create it.
    def __init__(self, name, color):
        self.name = name  # Every toy needs a name, so we save it here.
        self.color = color  # Every toy also has a color, which we save here.

# When we make a new toy, we follow the recipe (constructor) to give it a name and color.
my_toy = Toy("Dragon", "green")  # We made a green dragon toy!