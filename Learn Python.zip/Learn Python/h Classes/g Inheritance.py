# This is our basic Toy class, like a simple toy.
class Toy:
    def __init__(self, name, color):
        self.name = name
        self.color = color

    def introduce_self(self):
        print("Hi, I am " + self.name + " and I am " + self.color + "!")

# Now we make a special kind of Toy, like a Toy that can also move.
class MovingToy(Toy):  # MovingToy is a special kind of Toy.
    def move(self):
        print(self.name + " is moving!")

# We can make a MovingToy, which is still a Toy, but it can also move!
my_moving_toy = MovingToy("Car", "red")
my_moving_toy.introduce_self()  # It can still introduce itself.
my_moving_toy.move()  # And it can move!
