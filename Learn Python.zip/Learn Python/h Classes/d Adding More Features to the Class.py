# We add a new method to our 'Toy' class
class Toy:
    def __init__(self, name, color):
        self.name = name
        self.color = color

    def introduce_self(self):
        print("Hi, I am a " + self.color + " toy named " + self.name + "!")

    # New method that makes the toy perform an action
    def perform_action(self, action):
        print(self.name + " is now " + action + "!")



# Creating two toy objects from the 'Toy' class
toy1 = Toy("Teddy Bear", "brown")  # This is like making a brown teddy bear toy
toy2 = Toy("Race Car", "red")  # This is like making a red race car toy

# Each toy (object) has its own name and color, as specified when we created them.



# Now, toys can also perform actions
toy1.perform_action("jumping")  # This will print: "Teddy Bear is now jumping!"
toy2.perform_action("racing")  # This will print: "Race Car is now racing!"
