# Checking the weather
is_sunny = False
is_raining = True

# Deciding what to do based on the weather
if is_sunny:
    print("Let's play outside!")       # Won't run, it's not sunny
elif is_raining:
    print("Let's play board games!")    # Runs, because it's raining
else:
    print("Let's read books!")          # Won't run, because one of the above conditions is true
