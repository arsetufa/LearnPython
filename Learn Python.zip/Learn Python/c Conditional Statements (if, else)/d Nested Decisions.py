# Checking the weather
is_sunny = True
is_warm = False

# Deciding what to do
if is_sunny:
    if is_warm:
        print("Let's go swimming!")  # This won't run, it's not warm
    else:
        print("Let's play in the park!")  # This runs, it's sunny but not warm
