# Checking the day and weather
is_weekend = True
is_sunny = True

# Deciding what to do
if is_weekend and is_sunny:
    print("Let's go to the beach!")  # This runs, it's the weekend and sunny
else:
    print("Let's stay home.")
