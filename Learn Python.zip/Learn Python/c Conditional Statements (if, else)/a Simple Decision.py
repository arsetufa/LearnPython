# This is like checking if the sky is sunny
is_sunny = True

# If it's sunny, we play outside
if is_sunny:
    print("Let's play outside!")  # This line runs because it's sunny
