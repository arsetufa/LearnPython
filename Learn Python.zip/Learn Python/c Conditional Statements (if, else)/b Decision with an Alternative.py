# Let's check if it's sunny
is_sunny = False

# If it's sunny, we play outside. If not, we play inside.
if is_sunny:
    print("Let's play outside!")  # This line won't run because it's not sunny
else:
    print("Let's play inside!")   # This line runs because it's not sunny
