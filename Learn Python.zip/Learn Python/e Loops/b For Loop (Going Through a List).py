# We have a list of fruits
fruits = ["apple", "banana", "cherry"]

# We use a 'for' loop to go through each fruit in the list
for fruit in fruits:
    print(fruit)  # This line is executed for each fruit in the list, printing the fruit's name

# The loop repeats the print statement for each fruit in the list, so it will print 'apple', 'banana', and 'cherry'
