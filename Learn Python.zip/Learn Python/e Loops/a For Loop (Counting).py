# We use a 'for' loop to count from 1 to 5
for number in range(1, 6):  # 'range(1, 6)' gives us a sequence of numbers from 1 to 5
    print(number)  # This line is executed for each number in the sequence, printing the number

# The loop repeats the print statement for each number, so it will print 1, 2, 3, 4, and 5, each on a new line
