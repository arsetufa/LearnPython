# We start with 5 cookies in the jar
cookies_in_jar = 5

# We use a 'while' loop to keep eating cookies until the jar is empty
while cookies_in_jar > 0:  # This checks if there are still cookies left
    print("Eating a cookie!")
    cookies_in_jar -= 1  # This removes one cookie from the jar each time

    # We print how many cookies are left after eating one
    print("Cookies left:", cookies_in_jar)

# The loop stops when there are no more cookies left, so 'Eating a cookie!' is printed 5 times
