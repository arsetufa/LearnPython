# WARNING: This is an example of an infinite loop; it will keep running forever!
# while True:
#     print("I will print forever!")

# This loop has no condition to stop, so it will continually print the message
