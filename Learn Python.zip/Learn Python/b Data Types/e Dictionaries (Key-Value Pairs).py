# This is like having a treasure chest where each treasure is labeled. For example, the 'fruit' label has 'Apple'.
my_treasures = {"fruit": "Apple", "color": "Gold"}  # Dictionary: Collection of labeled items

# We can look inside the treasure chest to find a specific treasure using its label
print(my_treasures["fruit"])  # Shows 'Apple', the treasure labeled as 'fruit'
