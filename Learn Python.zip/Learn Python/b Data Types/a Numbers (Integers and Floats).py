# This is like having a toy car with the number 10 on it. It's a whole number, so we call it an 'integer'.
age = 10  # Integer: Whole number

# This is like a toy boat with the number 3.14. It's a number with a decimal point, so we call it a 'float'.
pi = 3.14  # Float: Decimal number

# We can show these toys to see their numbers
print(age)  # Shows the integer 10
print(pi)   # Shows the float 3.14
