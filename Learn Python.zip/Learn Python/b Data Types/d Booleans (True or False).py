# This is like having a light-up toy that can be either ON or OFF. Here, the toy is ON, so we say it's 'True'.
is_sunny = True  # Boolean: True or False value

# This is like having another light-up toy that is OFF, so we say it's 'False'.
is_raining = False  # Boolean: True or False value

# We can check if the toys are ON or OFF
print(is_sunny)   # Shows True, meaning the toy is ON
print(is_raining)  # Shows False, meaning the toy is OFF
