# This is like having a toy block with the word 'Dinosaur' on it. It's text, so we call it a 'string'.
favorite_dinosaur = "Dinosaur"  # String: Text

# We can show this toy block to see the word
print(favorite_dinosaur)  # Shows the word 'Dinosaur'
