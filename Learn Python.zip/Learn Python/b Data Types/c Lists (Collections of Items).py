# This is like a toy box where you can put multiple toys inside. Here, we put the numbers 1, 2, 3 in it.
numbers = [1, 2, 3]  # List: Collection of items

# We can look inside the toy box to see all the toys
print(numbers)  # Shows the list of numbers [1, 2, 3]
