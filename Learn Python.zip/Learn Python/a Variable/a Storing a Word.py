# We create a box and label it 'name' where we store the word 'Alice'
name = "Alice"

# We use the box labeled 'name' to get the word stored in it
print(name)  # This will show the word Alice
