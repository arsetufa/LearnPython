# We have two boxes, one labeled 'number1' storing 5, and another labeled 'number2' storing 3
number1 = 5
number2 = 3

# We create a new box labeled 'sum' to store the result of adding 'number1' and 'number2'
sum = number1 + number2

# We check what's inside the 'sum' box
print(sum)  # This will show 8, because 5 + 3 equals 8
