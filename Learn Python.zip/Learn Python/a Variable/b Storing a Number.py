# We create a box and label it 'age' where we store the number 7
age = 7

# Now, we can use the box labeled 'age' to find out the number stored in it
print(age)  # This will show the number 7
