# We have two boxes, one labeled 'first_name' storing 'Alice' and another labeled 'last_name' storing 'Smith'
first_name = "Alice"
last_name = "Smith"

# We create a new box labeled 'full_name' to store the combination of 'first_name' and 'last_name'
full_name = first_name + " " + last_name

# We look inside the 'full_name' box to see the full name
print(full_name)  # This will show 'Alice Smith'
