# We have a box labeled 'favorite_color' where we first store the word 'Blue'
favorite_color = "Blue"

# Now we decide to store a new word 'Green' in the box labeled 'favorite_color'
favorite_color = "Green"

# We look inside the box labeled 'favorite_color' to see the new word
print(favorite_color)  # This will show 'Green' now, instead of 'Blue'
