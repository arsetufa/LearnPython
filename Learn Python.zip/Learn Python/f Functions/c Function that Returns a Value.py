# This spell (function) is named 'add' and it needs two numbers
def add(number1, number2):
    result = number1 + number2  # It adds the numbers together
    return result  # It gives back the result

# We cast the spell with the numbers 3 and 4
sum = add(3, 4)  # The spell returns 7, which we store in 'sum'

# Now, we can see the result
print(sum)  # This will show the number 7
