# This spell (function) is named 'greet' and it needs a name to work properly
def greet(name):
    print("Hello, " + name + "!")  # The task is to greet the person by name

# We cast the spell for 'Alice'
greet("Alice")  # This will make the message "Hello, Alice!" appear

# We can use this spell for any name
greet("Bob")  # This will make the message "Hello, Bob!" appear
