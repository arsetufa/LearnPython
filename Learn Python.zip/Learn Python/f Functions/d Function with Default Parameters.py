# This spell (function) is named 'make_cake' and it has a default flavor 'vanilla'
def make_cake(flavor="vanilla"):
    print("Making a " + flavor + " cake!")  # The task is to make a cake of the specified flavor

# We cast the spell without specifying the flavor
make_cake()  # This will make the message "Making a vanilla cake!" appear

# We can also specify a flavor
make_cake("chocolate")  # This will make the message "Making a chocolate cake!" appear
