# This is how we create a spell (function) named 'say_hello'
def say_hello():
    print("Hello!")  # The task this spell performs is to print "Hello!"

# Now, we cast the spell (call the function)
say_hello()  # This will make the message "Hello!" appear

# You can cast this spell (call this function) whenever you want to say "Hello!"
