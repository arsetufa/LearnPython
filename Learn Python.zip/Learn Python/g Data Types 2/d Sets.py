# Creating a set of hobbies
hobbies = {"reading", "cycling", "swimming"}
# This is like putting a reading toy, a cycling toy, and a swimming toy into a bag.

# Adding a new item to the set
hobbies.add("painting")
# It's like putting a painting toy into the bag.

# Trying to add a duplicate item to the set
hobbies.add("reading")
# It's like trying to put another reading toy into the bag, but the bag refuses because there's already one.

# Removing an item from the set
hobbies.remove("cycling")
# It's like taking the cycling toy out of the bag.
