# Creating a tuple of colors
colors = ("red", "green", "blue")
# This is like putting pictures of red, green, and blue things in a photo album.

# Accessing an item from the tuple by its position
print(colors[0])
# This is like looking at the first picture in the album, which is of something red.

# Tuples are immutable, meaning you cannot add or remove items once the tuple is created.
