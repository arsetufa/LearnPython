# Creating a dictionary for a person's information
person_info = {"name": "Alice", "age": 30, "city": "New York"}
# This is like having a cabinet where there's a "name" drawer holding "Alice", an "age" drawer with 30, and a "city" drawer with "New York".

# Adding a new key-value pair to the dictionary
person_info["job"] = "Engineer"
# It's like adding a new drawer labeled "job" that holds "Engineer".

# Accessing an item from the dictionary by its key
print(person_info["name"])
# This is like opening the "name" drawer to see "Alice".

# Removing a key-value pair from the dictionary
del person_info["age"]
# It's like removing the "age" drawer from the cabinet.
