# Creating a list of favorite fruits
favorite_fruits = ["apple", "banana", "cherry"]
# This is like having a box where you put an apple toy, a banana toy, and a cherry toy, in that order.

# Adding a new fruit to the list
favorite_fruits.append("orange")
# It's like putting an orange toy into the box, after the cherry toy.

# Accessing an item from the list by its position
print(favorite_fruits[1])
# This is like picking the second toy in the box, which is a banana toy (since we start counting from 0).

# Removing an item from the list
favorite_fruits.remove("banana")
# It's like taking the banana toy out of the box.
